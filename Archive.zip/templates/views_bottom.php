<!-- Footer -->

<?php require_once(__DIR__."/../sections/views_footer.php") ?>
<!-- End of Footer -->

</body>

</html>
